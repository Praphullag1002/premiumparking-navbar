# premiumparking-navbar

> Made with create-react-library

[![NPM](https://img.shields.io/npm/v/premiumparking-navbar.svg)](https://www.npmjs.com/package/premiumparking-navbar) [![JavaScript Style Guide](https://img.shields.io/badge/code_style-standard-brightgreen.svg)](https://standardjs.com)

## Install

```bash
npm install --save premiumparking-navbar
```

## Usage

```jsx
import React, { Component } from 'react'

import MyComponent from 'premiumparking-navbar'
import 'premiumparking-navbar/dist/index.css'

class Example extends Component {
  render() {
    return <MyComponent />
  }
}
```

## License

MIT © [Praphullag1002](https://github.com/Praphullag1002)
